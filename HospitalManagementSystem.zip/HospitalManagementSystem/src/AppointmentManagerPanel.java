import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class AppointmentManagerPanel extends JPanel {
    private final AppointmentService appointmentService;

    private JTable patientsTable;
    private JTable doctorsTable;

    private DefaultTableModel patientsModel;
    private DefaultTableModel doctorsModel;

    private JLabel selectedPatientLabel;
    private JLabel selectedDoctorLabel;

    private JTextField dateField; // yyyy-MM-dd
    private JTextField timeField; // HH:mm or HH:mm:ss

    private Integer selectedPatientId = null;
    private Integer selectedDoctorId = null;

    // Colors & fonts
    private final Color BG = new Color(245, 247, 250);
    private final Color CARD = Color.WHITE;
    private final Color PRIMARY = new Color(52, 152, 219);
    private final Color PRIMARY_DARK = new Color(41, 128, 185);
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 18);
    private final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public AppointmentManagerPanel(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
        setLayout(new BorderLayout(12, 12));
        setBackground(BG);
        setBorder(new EmptyBorder(12, 12, 12, 12));

        // Title
        JLabel title = new JLabel("Manage Appointments");
        title.setFont(TITLE_FONT);
        title.setForeground(PRIMARY);
        add(title, BorderLayout.NORTH);

        // Center split: Patients | Doctors
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                wrapAsCard(createPatientsCard()), wrapAsCard(createDoctorsCard()));
        split.setResizeWeight(0.5);
        split.setBorder(null);
        add(split, BorderLayout.CENTER);

        // Bottom booking form
        add(wrapAsCard(createBookingForm()), BorderLayout.SOUTH);

        loadPatients();
        loadDoctors();
    }

    private JPanel wrapAsCard(JComponent inner) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD);
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.add(inner, BorderLayout.CENTER);
        return card;
    }

    private JComponent createPatientsCard() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setOpaque(false);

        JLabel lbl = new JLabel("Patients");
        lbl.setFont(TITLE_FONT);
        panel.add(lbl, BorderLayout.NORTH);

        patientsModel = new DefaultTableModel(new String[]{"ID", "Name", "Phone"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        patientsTable = new JTable(patientsModel);
        styleTable(patientsTable);

        patientsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && patientsTable.getSelectedRow() >= 0) {
                int row = patientsTable.getSelectedRow();
                selectedPatientId = (Integer) patientsModel.getValueAt(row, 0);
                String name = (String) patientsModel.getValueAt(row, 1);
                selectedPatientLabel.setText("Selected Patient: " + selectedPatientId + " - " + name);
            }
        });

        panel.add(new JScrollPane(patientsTable), BorderLayout.CENTER);

        JButton refresh = makeButton("Refresh Patients");
        refresh.addActionListener(e -> loadPatients());
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        south.setOpaque(false);
        south.add(refresh);
        panel.add(south, BorderLayout.SOUTH);

        return panel;
    }

    private JComponent createDoctorsCard() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setOpaque(false);

        JLabel lbl = new JLabel("Doctors");
        lbl.setFont(TITLE_FONT);
        panel.add(lbl, BorderLayout.NORTH);

        doctorsModel = new DefaultTableModel(new String[]{"ID", "Name", "Specialty"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        doctorsTable = new JTable(doctorsModel);
        styleTable(doctorsTable);

        doctorsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && doctorsTable.getSelectedRow() >= 0) {
                int row = doctorsTable.getSelectedRow();
                selectedDoctorId = (Integer) doctorsModel.getValueAt(row, 0);
                String name = (String) doctorsModel.getValueAt(row, 1);
                selectedDoctorLabel.setText("Selected Doctor: " + selectedDoctorId + " - " + name);
            }
        });

        panel.add(new JScrollPane(doctorsTable), BorderLayout.CENTER);

        JButton refresh = makeButton("Refresh Doctors");
        refresh.addActionListener(e -> loadDoctors());
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        south.setOpaque(false);
        south.add(refresh);
        panel.add(south, BorderLayout.SOUTH);

        return panel;
    }

    private JComponent createBookingForm() {
        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.anchor = GridBagConstraints.WEST;

        selectedPatientLabel = new JLabel("Selected Patient: —");
        selectedPatientLabel.setFont(LABEL_FONT);
        selectedDoctorLabel = new JLabel("Selected Doctor: —");
        selectedDoctorLabel.setFont(LABEL_FONT);

        dateField = makeTextField(10);
        timeField = makeTextField(7);

        JButton book = makePrimaryButton("Book Appointment");
        JButton view = makeButton("View All Appointments");

        // Row 0: selections
        gbc.gridx = 0; gbc.gridy = 0; form.add(selectedPatientLabel, gbc);
        gbc.gridx = 1; form.add(selectedDoctorLabel, gbc);

        // Row 1: date/time
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("Date (yyyy-MM-dd):"), gbc);
        gbc.gridx = 1; form.add(dateField, gbc);
        gbc.gridx = 2; form.add(new JLabel("Time (HH:mm):"), gbc);
        gbc.gridx = 3; form.add(timeField, gbc);

        // Row 2: buttons
        gbc.gridx = 0; gbc.gridy = 2; form.add(book, gbc);
        gbc.gridx = 1; form.add(view, gbc);

        book.addActionListener(e -> {
            if (selectedPatientId == null) {
                JOptionPane.showMessageDialog(this, "Please select a patient.");
                return;
            }
            if (selectedDoctorId == null) {
                JOptionPane.showMessageDialog(this, "Please select a doctor.");
                return;
            }
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Enter date as yyyy-MM-dd.");
                return;
            }
            if (!time.matches("\\d{2}:\\d{2}(:\\d{2})?")) {
                JOptionPane.showMessageDialog(this, "Enter time as HH:mm");
                return;
            }

            boolean ok = appointmentService.addAppointment(selectedPatientId, selectedDoctorId, date, time);
            if (ok) {
                JOptionPane.showMessageDialog(this, "✅ Appointment booked!");
                dateField.setText("");
                timeField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Could not save appointment. Check IDs and formats.");
            }
        });

        view.addActionListener(e -> new AppointmentViewWindow(appointmentService).setVisible(true));

        return form;
    }

    private void styleTable(JTable t) {
        t.setRowHeight(26);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        t.getTableHeader().setBackground(PRIMARY);
        t.getTableHeader().setForeground(Color.WHITE);
        t.setSelectionBackground(new Color(225, 239, 255));
        t.setSelectionForeground(Color.BLACK);
    }

    private JTextField makeTextField(int cols) {
        JTextField tf = new JTextField(cols);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220)),
                new EmptyBorder(6, 8, 6, 8)
        ));
        return tf;
    }

    private JButton makeButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(Color.WHITE);
        b.setForeground(PRIMARY_DARK);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220)),
                new EmptyBorder(6, 12, 6, 12)
        ));
        return b;
    }

    private JButton makePrimaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(PRIMARY_DARK); }
            public void mouseExited (java.awt.event.MouseEvent e) { b.setBackground(PRIMARY); }
        });
        return b;
    }

    private void loadPatients() {
        patientsModel.setRowCount(0);
        String sql = "SELECT id, name, phone FROM patient ORDER BY id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                patientsModel.addRow(new Object[]{rs.getInt("id"), rs.getString("name"), rs.getString("phone")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + e.getMessage());
        }
    }

    private void loadDoctors() {
        doctorsModel.setRowCount(0);
        String sql = "SELECT id, name, specialty FROM doctor ORDER BY id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                doctorsModel.addRow(new Object[]{rs.getInt("id"), rs.getString("name"), rs.getString("specialty")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading doctors: " + e.getMessage());
        }
    }
}
