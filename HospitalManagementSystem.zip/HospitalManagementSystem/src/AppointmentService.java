import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentService {

    public boolean addAppointment(int patientId, int doctorId, String date, String time) {
        // Normalize time: if "HH:mm" add ":00"
        if (time != null && time.matches("\\d{2}:\\d{2}")) {
            time = time + ":00";
        }
        String sql = "INSERT INTO appointment (patient_id, doctor_id, date, time) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ps.setInt(2, doctorId);
            ps.setString(3, date);   // yyyy-MM-dd
            ps.setString(4, time);   // HH:mm:ss
            return ps.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException fk) {
            // Likely wrong patient/doctor IDs
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> getAllAppointments() {
        List<String> list = new ArrayList<>();
        String sql = """
            SELECT a.id, p.name AS patient, d.name AS doctor, a.date, a.time
            FROM appointment a
            JOIN patient p ON a.patient_id = p.id
            JOIN doctor d ON a.doctor_id = d.id
            ORDER BY a.date DESC, a.time DESC, a.id DESC
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add("ID: " + rs.getInt("id") +
                        " | Patient: " + rs.getString("patient") +
                        " | Doctor: " + rs.getString("doctor") +
                        " | Date: " + rs.getDate("date") +
                        " | Time: " + rs.getTime("time"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
