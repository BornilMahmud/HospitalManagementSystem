// ================= HospitalManagementSystem.java =================
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.table.DefaultTableModel;

public class HospitalManagementSystem extends JFrame {
    private final DoctorService doctorService = new DoctorService();
    private final PatientService patientService = new PatientService();
    private final AppointmentService appointmentService = new AppointmentService();

    private DefaultTableModel doctorModel;
    private DefaultTableModel patientModel;

    public HospitalManagementSystem() {
        setTitle("Hospital Management System");
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Color BG = new Color(245, 247, 250);
        Color CARD = Color.WHITE;
        Color PRIMARY = new Color(52, 152, 219); // green for tab selection
        Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 18);
        Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 14);

        JTabbedPane tabs = new JTabbedPane(JTabbedPane.LEFT);
        tabs.setFont(LABEL_FONT);
        ImageIcon icon = new ImageIcon("src\\hpt.png"); // <-- your icon path
        setIconImage(icon.getImage());

        // Custom tab UI
        tabs.setUI(new BasicTabbedPaneUI() {
            @Override
            protected void installDefaults() {
                super.installDefaults();
                highlight = PRIMARY;
                selectedTabPadInsets = new Insets(2, 0, 2, 0);
                tabAreaInsets.left = 0;
            }

            @Override
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex,
                                              int x, int y, int w, int h, boolean isSelected) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isSelected ? PRIMARY : new Color(46, 204, 113));
                g2.fillRect(x, y, w, h);
            }

            @Override
            protected void paintText(Graphics g, int tabPlacement, Font font,
                                     java.awt.FontMetrics metrics, int tabIndex, String title,
                                     Rectangle textRect, boolean isSelected) {
                g.setFont(font);
                g.setColor(Color.WHITE);
                g.drawString(title, textRect.x, textRect.y + metrics.getAscent());
            }

            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return 50;
            }

            @Override
            protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
                return 200;
            }
        });

        // ---- Doctors Tab ----
        JPanel doctorsTab = createDoctorsTab(TITLE_FONT, CARD, PRIMARY);
        tabs.addTab("Doctors", doctorsTab);

        // ---- Patients Tab ----
        JPanel patientsTab = createPatientsTab(TITLE_FONT, CARD, PRIMARY);
        tabs.addTab("Patients", patientsTab);

        // ---- Appointments Tab ----
        tabs.addTab("Appointments", new AppointmentManagerPanel(appointmentService));

        add(tabs);

        // initial data
        refreshDoctors();
        refreshPatients();
    }

    private JPanel createDoctorsTab(Font TITLE_FONT, Color CARD, Color PRIMARY) {
        JPanel doctorsTab = new JPanel(new BorderLayout(12, 12));
        doctorsTab.setBackground(new Color(245, 247, 250));
        doctorsTab.setBorder(new EmptyBorder(12, 12, 12, 12));
        doctorsTab.add(cardHeader("Doctors", TITLE_FONT, PRIMARY), BorderLayout.NORTH);

        JPanel doctorsCard = new JPanel(new BorderLayout(8, 8));
        doctorsCard.setBackground(CARD);
        doctorsCard.setBorder(new EmptyBorder(12, 12, 12, 12));

        doctorModel = new DefaultTableModel(new String[]{"S/N", "Doctor Name", "Specialization"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable doctorTable = new JTable(doctorModel);
        styleTable(doctorTable, new Color(255, 165, 0)); // orange selection
        doctorsCard.add(new JScrollPane(doctorTable), BorderLayout.CENTER);

        JPanel docForm = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        docForm.setOpaque(false);
        JTextField name = textField(12);
        JTextField spec = textField(12);
        JButton addDoc = primaryButton("Add Doctor");
        addDoc.addActionListener(e -> {
            if (name.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this,"Name required"); return; }
            doctorService.addDoctor(name.getText().trim(), spec.getText().trim());
            name.setText(""); spec.setText("");
            refreshDoctors();
        });
        docForm.add(new JLabel("Name:")); docForm.add(name);
        docForm.add(new JLabel("Specialty:")); docForm.add(spec);
        docForm.add(addDoc);
        doctorsCard.add(docForm, BorderLayout.SOUTH);

        doctorsTab.add(doctorsCard, BorderLayout.CENTER);
        return doctorsTab;
    }

    private JPanel createPatientsTab(Font TITLE_FONT, Color CARD, Color PRIMARY) {
        JPanel patientsTab = new JPanel(new BorderLayout(12, 12));
        patientsTab.setBackground(new Color(245, 247, 250));
        patientsTab.setBorder(new EmptyBorder(12, 12, 12, 12));
        patientsTab.add(cardHeader("Patients", TITLE_FONT, PRIMARY), BorderLayout.NORTH);

        JPanel patientsCard = new JPanel(new BorderLayout(8, 8));
        patientsCard.setBackground(CARD);
        patientsCard.setBorder(new EmptyBorder(12, 12, 12, 12));

        patientModel = new DefaultTableModel(new String[]{"S/N", "Patient Name", "Phone"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable patientTable = new JTable(patientModel);
        styleTable(patientTable, new Color(225, 239, 255)); // light blue selection
        patientsCard.add(new JScrollPane(patientTable), BorderLayout.CENTER);

        JPanel patForm = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        patForm.setOpaque(false);
        JTextField pname = textField(12);
        JTextField pphone = textField(12);
        JButton addPat = primaryButton("Add Patient");
        addPat.addActionListener(e -> {
            if (pname.getText().trim().isEmpty() || pphone.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,"Name & Phone required"); return;
            }
            patientService.addPatient(pname.getText().trim(), pphone.getText().trim());
            pname.setText(""); pphone.setText("");
            refreshPatients();
        });
        patForm.add(new JLabel("Name:")); patForm.add(pname);
        patForm.add(new JLabel("Phone:")); patForm.add(pphone);
        patForm.add(addPat);
        patientsCard.add(patForm, BorderLayout.SOUTH);

        patientsTab.add(patientsCard, BorderLayout.CENTER);
        return patientsTab;
    }

    private JPanel cardHeader(String text, Font font, Color color) {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel(text);
        title.setFont(font);
        title.setForeground(color);
        header.add(title, BorderLayout.WEST);
        return header;
    }

    private JTextField textField(int cols) {
        JTextField tf = new JTextField(cols);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220)),
                new EmptyBorder(6, 8, 6, 8)
        ));
        return tf;
    }

    private JButton primaryButton(String text) {
        Color PRIMARY = new Color(52, 152, 219);
        Color HOVER = new Color(39, 174, 96); // green hover
        JButton b = new JButton(text);
        b.setBackground(PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(HOVER); }
            public void mouseExited (java.awt.event.MouseEvent e) { b.setBackground(PRIMARY); }
        });
        return b;
    }

    private void styleTable(JTable t, Color selection) {
        t.setRowHeight(26);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        t.getTableHeader().setBackground(new Color(52, 152, 219));
        t.getTableHeader().setForeground(Color.WHITE);
        t.setSelectionBackground(selection);
        t.setSelectionForeground(Color.BLACK);
    }

    private void refreshDoctors() {
        doctorModel.setRowCount(0);
        int serial = 1;
        for (String d : doctorService.getAllDoctors()) {
            String name = d;
            String spec = "";
            int idx = d.indexOf('(');
            int idx2 = d.indexOf(')');
            if (idx >= 0 && idx2 > idx) {
                name = d.substring(0, idx).trim();
                spec = d.substring(idx + 1, idx2).trim();
            }
            doctorModel.addRow(new Object[]{serial++, name, spec});
        }
    }

    private void refreshPatients() {
        patientModel.setRowCount(0);
        int serial = 1;
        for (String p : patientService.getAllPatients()) {
            String name = p;
            String phone = "";
            int idx = p.indexOf('(');
            int idx2 = p.indexOf(')');
            if (idx >= 0 && idx2 > idx) {
                name = p.substring(0, idx).trim();
                phone = p.substring(idx + 1, idx2).trim();
            }
            patientModel.addRow(new Object[]{serial++, name, phone});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HospitalManagementSystem().setVisible(true));
    }
}
