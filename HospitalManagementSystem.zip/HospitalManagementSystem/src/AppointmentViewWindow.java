import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class AppointmentViewWindow extends JFrame {

    public AppointmentViewWindow(AppointmentService appointmentService) {
        setTitle("Appointments List");
        setSize(700, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.CYAN);

        // Table columns
        String[] columns = {"ID", "Patient", "Doctor", "Date", "Time"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };

        // Fetch data from AppointmentService (which gets it from DB)
        for (String s : appointmentService.getAllAppointments()) {
            // Assuming your service returns a formatted string like "ID | Patient | Doctor | Date | Time"
            String[] parts = s.split("\\|"); // split by '|' if your service returns pipe-separated
            if (parts.length == 5) {
                model.addRow(new Object[]{
                        parts[0].trim(),
                        parts[1].trim(),
                        parts[2].trim(),
                        parts[3].trim(),
                        parts[4].trim()
                });
            }
        }

        // JTable setup
        JTable table = new JTable(model);
        table.setFillsViewportHeight(true);
        table.setBackground(Color.CYAN);
        table.setForeground(Color.BLACK);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.setSelectionBackground(Color.ORANGE);
        table.setSelectionForeground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(0, 128, 128));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBackground(Color.CYAN);
        scrollPane.getViewport().setBackground(Color.CYAN);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // Optional: Set your own icon
        ImageIcon icon = new ImageIcon("src\\hospital_bg.jpg");
        setIconImage(icon.getImage());
    }
}
