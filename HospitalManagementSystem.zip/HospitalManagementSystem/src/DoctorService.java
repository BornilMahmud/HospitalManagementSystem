import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoctorService {
    public void addDoctor(String name, String specialty) {
        String sql = "INSERT INTO doctor (name, specialty) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, specialty);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> getAllDoctors() {
        List<String> doctors = new ArrayList<>();
        String sql = "SELECT * FROM doctor";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                doctors.add(rs.getInt("id") + " - " + rs.getString("name") + " (" + rs.getString("specialty") + ")");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctors;
    }
}
