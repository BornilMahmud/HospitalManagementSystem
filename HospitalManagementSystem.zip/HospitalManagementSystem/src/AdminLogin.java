// ================= AdminLogin.java =================
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class AdminLogin extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;

    public AdminLogin() {
        setTitle("Admin Login");
        setSize(842, 411);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // ==========================
        // 1️⃣ Window icon
        // ==========================
        ImageIcon icon = new ImageIcon("src\\loginicon.png"); // <-- your icon path
        setIconImage(icon.getImage());

        // ==========================
        // 2️⃣ Background image
        // ==========================
        ImageIcon bgIcon = new ImageIcon("src\\login.jpg"); // <-- your background path
        JLabel background = new JLabel(bgIcon);
        background.setLayout(new GridBagLayout());
        setContentPane(background);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.BLACK);
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        background.add(userLabel, gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(20);
        background.add(usernameField, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.BLACK);
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        background.add(passLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        background.add(passwordField, gbc);

        // Show password checkbox
        gbc.gridx = 1; gbc.gridy = 2;
        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setOpaque(false);
        showPasswordCheckBox.setForeground(Color.BLACK);
        showPasswordCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('•');
            }
        });
        background.add(showPasswordCheckBox, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setOpaque(false);

        JButton loginButton = createButton("Login", new Color(52, 152, 219), new Color(46, 204, 113));
        loginButton.addActionListener(e -> login());

        JButton cancelButton = createButton("Cancel", new Color(231, 76, 60), new Color(192, 57, 43));
        cancelButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        background.add(buttonPanel, gbc);
    }

    // ==========================
    // Button styling helper
    // ==========================
    private JButton createButton(String text, Color normal, Color hover) {
        JButton b = new JButton(text);
        b.setBackground(normal);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 16));
        b.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(normal); }
        });
        return b;
    }

    // ==========================
    // Login logic
    // ==========================
    private void login() {
        String username = usernameField.getText().trim();
        String password = String.valueOf(passwordField.getPassword());

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "✅ Login Successful!");
                new HospitalManagementSystem().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Invalid Username or Password");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminLogin().setVisible(true));
    }
}
